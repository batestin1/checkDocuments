
from setuptools import setup

setup(
    name = 'checkDocuments',
    version = '1.0.0',
    author = 'Bates',
    author_email = 'Bates@mailer.com.br',
    packages = ['checkDocuments'],
    description = 'a way to make your life easier',
    long_description = 'file: README.md',
    url = 'https://github.com/batestin1/',
    project_urls = {'Codigo fonte' : 'https://github.com/batestin1/', 'Download' : 'https://github.com/batestin1/'},
    keywords = 'a way to make your life easier',
    classifiers = []
)